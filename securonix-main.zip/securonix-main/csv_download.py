import logging
import requests
import csv
import time
import datetime
import os
import urllib3

import datetime
import os

urllib3.disable_warnings()

now = datetime.datetime.now()

# Set your client ID and client secret for the CrowdStrike OAuth2 endpoint
client_id = "294db990d4bf478986b23e1f9dc2cb5e"
client_secret = "9b01plI32PTYGVUa6rnEgRF4Aqu57ymtOH8JWzNM"
logging_filename = now.strftime('ti_%d%m%Y.log')

# Set up logging to a file
# logging.basicConfig(filename='/var/log/ti.log', level=logging.DEBUG)

logging.basicConfig(format='%(asctime)s,%(msecs)d %(levelname)-8s [%(filename)s:%(lineno)d] %(message)s',
    handlers=[
        logging.FileHandler(logging_filename),
        logging.StreamHandler()
    ],
    datefmt='%Y-%m-%d:%H:%M:%S',
    level=logging.DEBUG)

payload = {
     "client_id": client_id,
     "client_secret": client_secret
}
headers = {
    "accept": "application/json",
    "Content-Type": "application/x-www-form-urlencoded"
}


path = "csv/"

for file_name in os.listdir(path):
    # construct full file path
    file = path + file_name

    if os.path.isfile(file):
        os.remove(file)
        logging.debug('Deleting file: %s', file)
    else:
        logging.debug('Files does not exist: %s', file)


# Get the token from the response
token = "vKiPE1tDj7NFyr2tGw9fy6TjL9H682E5dH766fD2"

# Set the headers for the Indicators API call with the token
headers = {
        "Authorization": token,
        "Content-Type": "application/json"
}
resource = {}
# Send a GET request to each Indicators API URL with the headers
url="https://ti.malwarebucket.com/attributes/restSearch"
types={"md5":"md5", "url": "url", "sha256": "sha256", "domain": "domain", "ip-src": "ip-src", "ip-dst": "ip-dst"}
for type_key, type_value in types.items():
    #data={"returnFormat":"json", "limit":"8000", "type":type_value, "timestamp": "5d"}
    data={"returnFormat":"json", "limit":"8000", "type":type_value, "attribute_timestamp": "1d"}
    response = requests.post(url, headers=headers,json=data,verify=False)
    #logging.debug(response.content)
    #logging.debug(response.status_code)

    if response.status_code == 200:
        # Get the data from the response in JSON format
        data = response.json()
        len_ =  len(data["response"]["Attribute"])
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d:%H:%M:%S")
        filename = f"{type_value}_indicators_{timestamp}.csv"
        filepath = "csv/"
        fullpath = filepath + filename
        with open(fullpath, "w", newline="") as csv_file:
            # Create a CSV writer
            writer = csv.writer(csv_file)
            # Write the headers
            writer.writerow(["indicator", "type", "last_updated"])
            for i in range(0,len_):
                #logging.debug(data)
                #logging.debug(data["response"]["Attribute"][0]["value"])
                # Extract the resources from the response
                resource["indicator"] = data["response"]["Attribute"][i]["value"]
                resource["type"] = type_value
                resource["last_updated"] = data["response"]["Attribute"][i]["timestamp"]
                writer.writerow([resource["indicator"], resource["type"], resource["last_updated"]])

        logging.debug(f"Data saved to {filename}")